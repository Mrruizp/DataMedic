  <footer class="main-footer">
    <strong>Copyright &copy;<?php echo date('Y'); ?><a href="http://alfirk.org.pe" class="text-primary"> Alfirk</a>.</strong>
    Todos los derechos reservados.
    <div class="float-right d-none d-sm-inline-block">
      <b>Version</b> 1.0
    </div>
  </footer>