<?php

define("C_NOMBRE_SOFTWARE", "DataMedic");